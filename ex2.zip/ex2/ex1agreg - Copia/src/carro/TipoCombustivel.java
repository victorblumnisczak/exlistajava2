package carro;

public enum TipoCombustivel {
    GASOLINA,
    DIESEL,
    ELETRICO
}
