package carro;

public class Carro {
    private String modelo;
    private Motor motor;

    public Carro(String modelo, Motor motor) {
        this.modelo = modelo;
        this.motor = motor;
    }

    public void ligarCarro() {
        motor.ligar();
    }

    public void desligarCarro() {
        motor.desligar();
    }

    public void turboBoost() {
        motor.aumentarPotencia(50);
        System.out.println("Turbo Boost ativado! potencia aumentada em 50 cavalos.");
    }

    public void reduzirPotenciaMotor() {
        motor.reduzirPotencia(30);
        System.out.println("potencia reduzida em 30 cavalos.");
    }

    public void acionarFreio(int decrementoRpm) {
        motor.reduzirRpm(decrementoRpm);
    }

    public void acionarAcelerador(int incrementoRpm) {
        motor.acelerar(incrementoRpm);
    }

    // Getters
    public String getModelo() {
        return modelo;
    }

    public Motor getMotor() {
        return motor;
    }
}
