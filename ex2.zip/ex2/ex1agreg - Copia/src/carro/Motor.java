package carro;

public class Motor {
    private String modelo;
    private int potencia;
    private TipoCombustivel tipoCombustivel;
    private int cilindradas;
    private boolean ligado;
    private int rpm;

    public Motor(String modelo, int potencia, TipoCombustivel tipoCombustivel, int cilindradas) {
        this.modelo = modelo;
        this.potencia = potencia;
        this.tipoCombustivel = tipoCombustivel;
        this.cilindradas = cilindradas;
        this.ligado = false;
        this.rpm = 0;
    }

    public void ligar() {
        if (!ligado) {
            ligado = true;
            rpm = 1000;
            System.out.println("o motor ligado. RPM inicial: " + rpm);
        } else {
            System.out.println("o motor ja esta ligado.");
        }
    }

    public void desligar() {
        if (ligado) {
            ligado = false;
            rpm = 0;
            System.out.println("motor desligado.");
        } else {
            System.out.println("O motor ja esta desligado.");
        }
    }

    public void aumentarPotencia(int incremento) {
        potencia += incremento;
        System.out.println("potencia aumentada para: " + potencia + " cavalos.");
    }

    public void reduzirPotencia(int decremento) {
        potencia -= decremento;
        System.out.println("potencia reduzida para: " + potencia + " cavalos.");
    }

    public void acelerar(int incrementoRpm) {
        if (ligado) {
            rpm += incrementoRpm;
            System.out.println("acelerando... RPM atual: " + rpm);
        } else {
            System.out.println("o motor esta desligado. ligue o motor primeiro.");
        }
    }

    public void reduzirRpm(int decrementoRpm) {
        if (ligado && rpm >= decrementoRpm) {
            rpm -= decrementoRpm;
            System.out.println("Reduzindo RPM... RPM atual: " + rpm);
        } else {
            System.out.println("o motor esta desligado ou o valor de redução eh maior que o RPM atual.");
        }
    }

    public String getModelo() {
        return modelo;
    }

    public int getPotencia() {
        return potencia;
    }

    public TipoCombustivel getTipoCombustivel() {
        return tipoCombustivel;
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public boolean isLigado() {
        return ligado;
    }

    public int getRpm() {
        return rpm;
    }
}
