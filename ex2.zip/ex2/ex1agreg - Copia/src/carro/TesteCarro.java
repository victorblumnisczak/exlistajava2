package carro;

public class TesteCarro {
    public static void main(String[] args) {
        Motor motorHonda = new Motor("VTEC", 210, TipoCombustivel.GASOLINA, 2000);
        Carro hondaCivic = new Carro("Honda Civic", motorHonda);

        hondaCivic.ligarCarro();
        hondaCivic.acionarAcelerador(8000);
        hondaCivic.turboBoost();
        hondaCivic.acionarFreio(4000);
        hondaCivic.reduzirPotenciaMotor();
        hondaCivic.desligarCarro();
    }
}
