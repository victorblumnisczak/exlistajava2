package livros;

import java.util.ArrayList;
import java.util.List;

public class Livro {
    private String titulo;
    private String autor;
    private List<Pagina> paginas;

    public Livro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.paginas = new ArrayList<>();
    }

    public void adicionarPagina(String conteudo) {
        int numeroNovaPagina = paginas.size() + 1;
        Pagina novaPagina = new Pagina(numeroNovaPagina, conteudo);
        paginas.add(novaPagina);
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public List<Pagina> getPaginas() {
        return new ArrayList<>(paginas); // Retorna uma cópia da lista para encapsulamento
    }
}