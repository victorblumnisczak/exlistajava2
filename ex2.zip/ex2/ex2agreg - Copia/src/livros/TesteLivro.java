package livros;

public class TesteLivro {
    public static void main(String[] args) {
        Livro meuLivro = new Livro("A Arte da Computaria", "karl Marx");

        meuLivro.adicionarPagina("Capitulo 1: Introducao a Programacao");
        meuLivro.adicionarPagina("Capitulo 2: Estruturas de Dados");
        meuLivro.adicionarPagina("Capitulo 3: Algoritmos");

        System.out.println("Livro: " + meuLivro.getTitulo());
        System.out.println("Autor: " + meuLivro.getAutor());
        System.out.println("Numero de paginas: " + meuLivro.getPaginas().size());

        for (Pagina pagina : meuLivro.getPaginas()) {
            System.out.println("Pagina " + pagina.getNumero() + ": " + pagina.getConteudo());
        }
    }
}
